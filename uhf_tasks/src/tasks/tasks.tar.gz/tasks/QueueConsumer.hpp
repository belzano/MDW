#pragma once

#include "uhf/threads/WorkerThread.hpp"
#include "Queue.hpp"

namespace uhf {
namespace tasks {
	
	/////////////////////////////////////////////////////////////////////
		
	class QueueConsumer : public uhf::threads::WorkerThread
	{
		public:
		
			QueueConsumer(QueuePtr);
		
			virtual int run() override;
			
		private:
			QueuePtr m_queue;
	};

}
}
