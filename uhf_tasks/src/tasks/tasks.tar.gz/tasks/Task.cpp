#include "uhf/tasks/Task.hpp"

////////////////////////////////////////////////////////////

namespace uhf {	
namespace tasks {

	Task::Task(const char* iType)
		: m_type(iType) 
	{
	}
}
}
